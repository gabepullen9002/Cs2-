﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cs2
{
    public static class Offsets
    {

        public static int dwViewAngles = 0x1880DC0;
        public static int dwLocalPlayerPawn = 0x16C8F38;
        public static int dwEntityList = 0x17C1950;
        public static int dwViewMatrix = 0x1820150;

        public static int m_hPlayerPawn = 0x7EC;
        public static int m_iHealth = 0x32C;
        public static int m_vOldOrigin = 0x1224;
        public static int m_iTeamNum = 0x3BF;
        public static int m_vecViewOffset = 0xC48;
        public static int m_lifeState = 0x330;
        public static int m_modelState = 0x160;
        public static int m_pGAmeSceneNode = 0x310;
        public static int m_name = 0x30;
        public static int m_moduleState = 0x160;
        public static int m_pGameSceneNode = 0x310;
        public static int m_flFlashBanfTime = 0x1454;
        public static int m_desirefov = 0x6D4;
    }
}

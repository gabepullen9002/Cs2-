﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using ClickableTransparentOverlay;
using ImGuiNET;

namespace Cs2
{
    public class Renderer : Overlay
    {

        public Vector2 overlaySize = new Vector2(1920, 1080);
       
        public List<Entity> entitiesCopy = new List<Entity>();
        public Entity localPlayerCopy = new Entity();
        
        



        public bool aimBot = true;
        public bool aimOnTeam = true;
        public bool leaveBody = false;
        
        
     


   
        
        protected override void Render()
        {
            ImGui.Begin("Menu");

            
            ImGui.Checkbox("aimbot", ref aimOnTeam);
            ImGui.Checkbox("leaveBody", ref leaveBody);
            
               
            
            
        




        }

       
    }

    
    
}
